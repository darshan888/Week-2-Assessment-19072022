object Ans1
{
   def main(args: Array[String])
   {
     val str = "https://www.google.com";
     val reversedAndToUpperCase = str.reverse.toUpperCase();
     println(reversedAndToUpperCase);
}
}